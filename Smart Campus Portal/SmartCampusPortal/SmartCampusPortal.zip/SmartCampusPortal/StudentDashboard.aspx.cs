﻿using System;
using System.Linq;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SmartCampusPortal
{
    public partial class StudentDashboard : Page
    {
        private DataClassesDataContext db;
        private int studentId;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Enforce Student role
            if (Session["UserID"] == null ||
                Session["Role"]?.ToString() != "Student")
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            // Initialize data context
            db = new DataClassesDataContext(
                  ConfigurationManager
                    .ConnectionStrings["SmartCampusDBConnectionString"]
                    .ConnectionString);

            if (!IsPostBack)
            {
                // Load all panels once
                LoadProfile();
                LoadCourses();
                LoadAnnouncements();
                LoadAvailableSections();
            }
            else
            {
                // Preserve studentId on postback
                studentId = (int)ViewState["StudentID"];
            }
        }

        private void LoadProfile()
        {
            int userId = Convert.ToInt32(Session["UserID"]);
            var info = (from u in db.Users
                        join s in db.Students on u.UserID equals s.UserID
                        where u.UserID == userId
                        select new
                        {
                            u.Username,
                            u.FullName,
                            u.Email,
                            s.Major,
                            s.EnrollmentDate,
                            s.GPA,
                            s.StudentID
                        })
                       .FirstOrDefault();

            if (info == null)
            {
                Session.Clear();
                Response.Redirect("~/Login.aspx");
                return;
            }

            litFullName.Text = info.FullName;
            litUsername.Text = info.Username;
            litEmail.Text = info.Email;
            litMajor.Text = info.Major;
            litEnrollDate.Text = info.EnrollmentDate.ToString("yyyy-MM-dd");
            litGPA.Text = info.GPA?.ToString("F2") ?? "N/A";

            studentId = info.StudentID;
            ViewState["StudentID"] = studentId;
        }

        private void LoadCourses()
        {
            var enrolled = from sc in db.StudentCourses
                           join cs in db.CourseSections on sc.SectionID equals cs.SectionID
                           join c in db.Courses on cs.CourseID equals c.CourseID
                           where sc.StudentID == studentId
                           select new
                           {
                               c.CourseCode,
                               c.Title,
                               cs.Semester,
                               cs.Year,
                               Grade = sc.Grade ?? "—"
                           };

            gvCourses.DataSource = enrolled.ToList();
            gvCourses.DataBind();
        }

        private void LoadAnnouncements()
        {
            var sectionIds = db.StudentCourses
                               .Where(sc => sc.StudentID == studentId)
                               .Select(sc => sc.SectionID)
                               .ToList();

            var anns = db.Announcements
                         .Where(a => a.SectionID.HasValue
                                  && sectionIds.Contains(a.SectionID.Value))
                         .OrderByDescending(a => a.PostDate)
                         .Select(a => new
                         {
                             a.Title,
                             a.Content,
                             a.PostDate
                         })
                         .ToList();

            rptAnnouncements.DataSource = anns;
            rptAnnouncements.DataBind();
        }

        private void LoadAvailableSections()
        {
            // Already enrolled section IDs
            var enrolledIds = db.StudentCourses
                                .Where(sc => sc.StudentID == studentId)
                                .Select(sc => sc.SectionID);

            // Fetch sections with prereq checks:
            // prereq==null OR student has completed prereq
            var available = from cs in db.CourseSections
                            join c in db.Courses on cs.CourseID equals c.CourseID
                            where !enrolledIds.Contains(cs.SectionID)
                            let prereq = c.PrerequisiteCourseID
                            where prereq == null
                               || db.StudentCourses
                                    .Join(db.CourseSections,
                                          sc => sc.SectionID,
                                          sec => sec.SectionID,
                                          (sc, sec) => sec.CourseID)
                                    .Contains(prereq.Value)
                            select new
                            {
                                cs.SectionID,
                                Label = c.CourseCode
                                      + " – " + cs.Semester
                                      + " " + cs.Year
                            };

            ddlAvailableSections.Items.Clear();
            ddlAvailableSections.Items.Add(
                new ListItem("-- Select Section --", ""));

            foreach (var s in available)
                ddlAvailableSections.Items
                  .Add(new ListItem(s.Label, s.SectionID.ToString()));
        }

        protected void btnEnroll_Click(object sender, EventArgs e)
        {
            lblEnrollMsg.CssClass = "text-danger";
            lblEnrollMsg.Text = "";

            if (!int.TryParse(ddlAvailableSections.SelectedValue,
                              out int sectionId))
            {
                lblEnrollMsg.Text = "Please select a valid section.";
                return;
            }

            // Prevent duplicates
            if (db.StudentCourses.Any(sc =>
                 sc.StudentID == studentId
              && sc.SectionID == sectionId))
            {
                lblEnrollMsg.Text = "You are already enrolled.";
                return;
            }

            // Insert enrollment
            var enroll = new StudentCourse
            {
                StudentID = studentId,
                SectionID = sectionId,
                EnrollmentDate = DateTime.Now,
                Grade = null
            };
            db.StudentCourses.InsertOnSubmit(enroll);
            db.SubmitChanges();

            lblEnrollMsg.CssClass = "text-success";
            lblEnrollMsg.Text = "Enrolled successfully!";

            // Refresh UI
            LoadCourses();
            LoadAvailableSections();
        }

        protected void btnChangePassword_Click(object sender, EventArgs e)
        {
            lblPasswordMessage.CssClass = "text-danger";
            lblPasswordMessage.Text = "";

            string oldPwd = txtOldPassword.Text.Trim();
            string newPwd = txtNewPassword.Text.Trim();
            string confirm = txtConfirmPassword.Text.Trim();

            if (newPwd != confirm)
            {
                lblPasswordMessage.Text = "New passwords do not match.";
                return;
            }

            var user = db.Users.FirstOrDefault(u =>
                         u.UserID == Convert.ToInt32(Session["UserID"]));
            if (user == null)
            {
                lblPasswordMessage.Text = "User not found.";
                return;
            }

            // Verify old password
            if (user.PasswordHash != PasswordHasher.HashPassword(oldPwd))
            {
                lblPasswordMessage.Text = "Old password is incorrect.";
                return;
            }

            user.PasswordHash = PasswordHasher.HashPassword(newPwd);
            db.SubmitChanges();

            lblPasswordMessage.CssClass = "text-success";
            lblPasswordMessage.Text = "Password changed successfully.";
        }
    }
}
